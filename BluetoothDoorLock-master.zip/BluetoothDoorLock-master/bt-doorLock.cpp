

#include <iostream>
using std::cin;
using std::cout;
using std::endl;



int main(){

    cout << "This program locks/unlocks a door if a nearby trusted bluetooth devices is detected." << endl;

    

    return 0;
}
